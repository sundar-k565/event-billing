# Menu Import Summary

- Categories: 36
- Product records in seed: 205
- Initially billable (active and not needs_confirmation): 196
- Requires admin confirmation before billing: 7
- Unpriced seasonal items: 2
- Unresolved modifier rules: 2

The seed deliberately preserves source ambiguity instead of inventing missing prices/variants.
