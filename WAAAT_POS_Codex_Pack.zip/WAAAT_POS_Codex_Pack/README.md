# WAAAT POS — Codex Input Pack

This folder contains the product and technical context for building the POS with Codex.

## Recommended repository layout

```text
/
├── AGENTS.md
├── README.md
├── docs/
│   ├── PRD.md
│   ├── ARCHITECTURE.md
│   ├── DATA_MODEL.md
│   ├── API_SPEC.md
│   ├── UI_SPEC.md
│   ├── PRINTING.md
│   ├── ACCEPTANCE_TESTS.md
│   ├── IMPLEMENTATION_PLAN.md
│   ├── MENU_REVIEW_NOTES.md
│   └── CODEX_PROMPT.md
├── data/
│   ├── MENU_SEED.json
│   └── MENU_SEED.csv
└── supabase/
```

## How to use with Codex

1. Create an empty GitHub repository.
2. Put this pack into the repo.
3. Open the repository with Codex.
4. Ask Codex to read `AGENTS.md` and all files under `docs/`.
5. Use `docs/CODEX_PROMPT.md` as the initial implementation request.
6. Ask Codex to implement the project in the slices from `docs/IMPLEMENTATION_PLAN.md`.
7. Do not ask Codex to implement every future feature. Keep V1 frozen.

## Important unresolved input
The exact printer model has not been provided yet.
This does not block the web application build; it blocks only final printer-specific QA/tuning.

## Menu source note
The food menu PDF is treated as the food source, while the WAAAT menu-card image is treated as the bar/alcohol source. Price conflicts in overlapping beverage items are explicitly documented instead of silently merged.
